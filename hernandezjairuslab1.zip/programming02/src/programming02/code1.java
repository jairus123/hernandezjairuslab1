package programming02;

public class code1 {
	private String country;
	private String date;
	private String city;
	private String intention;
	private String length;
		
		public code1(String country, String date, String city, String intention, String length) {
			this.country = country;
			this.date = date;
			this.city = city;
			this.intention = intention;
			this.length = length;
	}

		public String getCountry() {
			return this.country;	
		}
		
		public String getDate() {
			return this.date;	
		}
		
		public String getCity() {
			return this.city;	
		}
		
		public String getIntention() {
			return this.intention;	
		}
		
		public String getLength() {
			return this.length;	
		}
			
			public void activity (String activity) {
				System.out.println("This person will do " + activity);
			}
			
			public void eat (String eat) {
				System.out.println("This person will eat " + eat);
			}
			
			
}