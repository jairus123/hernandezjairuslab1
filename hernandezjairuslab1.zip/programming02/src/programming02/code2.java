package programming02;

public class code2 {
	public static void main(String[] args) {
		code1 trip = new code1("New York, USA", "February 11, 2020", "New York City", "Vacation", "1 month"); 
		System.out.println(	"The Country: " + trip.getCountry());
		System.out.println("The City: " + trip.getCity());
		System.out.println("The Date: " + trip.getDate());
		System.out.println("Intention: " + trip.getIntention() );
		System.out.println("Length: " + trip.getLength());
		trip.activity("Sight Seeing");
		trip.eat("Local Delicacies");
	}
 }



